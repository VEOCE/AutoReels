from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    google_api_key: str = os.getenv("GOOGLE_API_KEY", "")
    veo_model: str = os.getenv("VEO_MODEL", "veo-3.1-generate-preview")
    meta_graph_version: str = os.getenv("META_GRAPH_VERSION", "")
    meta_page_id: str = os.getenv("META_PAGE_ID", "")
    meta_page_access_token: str = os.getenv("META_PAGE_ACCESS_TOKEN", "")
    publish_mode: str = os.getenv("PUBLISH_MODE", "review").lower()
    output_dir: Path = Path(os.getenv("OUTPUT_DIR", "output"))
    database_path: Path = Path(os.getenv("DATABASE_PATH", "data/state.sqlite3"))
    timezone: str = os.getenv("TIMEZONE", "Asia/Jakarta")

settings = Settings()
if settings.publish_mode not in {"review", "publish"}:
    raise ValueError("PUBLISH_MODE hanya boleh 'review' atau 'publish'")
