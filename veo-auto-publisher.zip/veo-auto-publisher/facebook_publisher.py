"""Facebook Page Reels API scaffold. Use only with Page admin permission and valid Meta setup."""
from pathlib import Path
import requests
from config import settings

def publish_page_reel(video_path: Path, caption: str) -> str:
    if settings.publish_mode != "publish":
        raise RuntimeError("Mode review aktif. Publikasi dinonaktifkan.")
    if not all([settings.meta_graph_version, settings.meta_page_id, settings.meta_page_access_token]):
        raise RuntimeError("META_GRAPH_VERSION, META_PAGE_ID, dan META_PAGE_ACCESS_TOKEN wajib diatur")
    base = f"https://graph.facebook.com/{settings.meta_graph_version}"
    params = {"access_token": settings.meta_page_access_token}
    # Phase 1: create an upload session
    start = requests.post(f"{base}/{settings.meta_page_id}/video_reels",
                          params={**params, "upload_phase": "start"}, timeout=60)
    start.raise_for_status()
    data = start.json()
    video_id, upload_url = data["video_id"], data["upload_url"]
    # Phase 2: transfer video bytes to the upload URL
    with video_path.open("rb") as f:
        upload = requests.post(upload_url,
            headers={"Authorization": f"OAuth {settings.meta_page_access_token}",
                     "offset": "0", "file_size": str(video_path.stat().st_size)},
            data=f, timeout=300)
    upload.raise_for_status()
    # Phase 3: finish/publish
    finish = requests.post(f"{base}/{settings.meta_page_id}/video_reels",
        params={**params, "upload_phase": "finish", "video_id": video_id,
                "video_state": "PUBLISHED", "description": caption}, timeout=120)
    finish.raise_for_status()
    return video_id
