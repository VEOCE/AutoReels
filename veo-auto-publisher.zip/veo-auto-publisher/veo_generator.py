from pathlib import Path
import time
from google import genai
from google.genai import types
from config import settings


def generate_clip(prompt: str, destination: Path) -> Path:
    """Generate an 8-second Veo clip. Confirm model/params against current API docs."""
    if not settings.google_api_key:
        raise RuntimeError("GOOGLE_API_KEY belum diatur di .env")
    client = genai.Client(api_key=settings.google_api_key)
    operation = client.models.generate_videos(
        model=settings.veo_model,
        prompt=prompt,
        config=types.GenerateVideosConfig(
            aspect_ratio="9:16",
            duration_seconds=8,
            number_of_videos=1,
        ),
    )
    while not operation.done:
        time.sleep(10)
        operation = client.operations.get(operation)
    if not operation.response or not operation.response.generated_videos:
        raise RuntimeError(f"Veo tidak mengembalikan video: {operation}")
    video = operation.response.generated_videos[0].video
    destination.parent.mkdir(parents=True, exist_ok=True)
    client.files.download(file=video)
    video.save(str(destination))
    return destination
