import argparse, json, logging, re
from pathlib import Path
from datetime import datetime
from config import settings
from content import choose_fact, build_caption, build_video_prompt
from veo_generator import generate_clip
from video_postprocess import make_15s_vertical
from storage import init_db, save_job

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.FileHandler("logs/app.log"), logging.StreamHandler()])

def create_draft(topic: str | None = None):
    init_db(settings.database_path)
    item = choose_fact(topic)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    work = settings.output_dir / "work"
    review = settings.output_dir / "review"
    work.mkdir(parents=True, exist_ok=True); review.mkdir(parents=True, exist_ok=True)
    clip = generate_clip(build_video_prompt(item), work / f"{stamp}_{item['id']}_8s.mp4")
    final = make_15s_vertical(clip, review / f"{stamp}_{item['id']}_15s.mp4")
    caption = build_caption(item)
    metadata = {"fact": item, "caption": caption, "video": str(final),
                "status": "PENDING_REVIEW", "created_at": stamp}
    (review / f"{stamp}_{item['id']}.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    save_job(settings.database_path, item, "PENDING_REVIEW", final, caption)
    logging.info("Draft dibuat: %s", final)
    # No auto-publish in this starter. Review the fact, video, rights, and Page policy first.
    return final

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    once = sub.add_parser("once"); once.add_argument("--topic", choices=["hewan","angkasa","alam","sejarah","sains"])
    sub.add_parser("schedule")
    args = parser.parse_args()
    Path("logs").mkdir(exist_ok=True)
    if args.command == "once": create_draft(args.topic)
    else:
        from scheduler import start_scheduler
        start_scheduler()
