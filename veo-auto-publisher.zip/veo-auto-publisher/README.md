# Veo Auto Publisher — Fakta Unik (starter)

Starter project untuk membuat video edukasi vertikal 15 detik dari fakta yang sudah disiapkan, meninjau hasilnya, lalu menyiapkan publikasi Facebook Page melalui Meta Graph API.

> **Penting:** Google Veo tidak selalu menghasilkan durasi 15 detik dalam satu generasi. Model Veo 3.1 umumnya menghasilkan 4, 6, atau 8 detik. Starter ini membuat klip 8 detik lalu membuat versi 15 detik dengan FFmpeg (pemotongan/pengulangan/penyambungan). Periksa hasil visual/audio sebelum digunakan. Referensi: https://ai.google.dev/gemini-api/docs/video dan https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/video/generate-videos-from-text
>
> **Mode bawaan = REVIEW.** Program menghasilkan draft dan tidak mem-posting tanpa tindakan eksplisit. Publikasi Page memerlukan aplikasi Meta, izin dan Page access token yang sah. Tidak mendukung posting profil pribadi.

## Fitur
- 5 job harian WIB: 06.00, 09.00, 12.00, 15.00, 19.00.
- Topik fakta: hewan, luar angkasa, alam, sejarah, sains.
- Fakta disimpan sebagai data terkurasi di `data/facts.json`; setiap fakta wajib punya sumber URL dan ringkasan.
- Video vertikal 9:16, hasil MP4 15 detik menggunakan FFmpeg.
- Caption dan hashtag dibuat dari record fakta (tanpa mengarang klaim tambahan).
- Mode review: draft disimpan ke `output/review/` beserta metadata.
- Modul Facebook Page memakai dua fase Reels API; aktifkan hanya setelah pemilik Page/admin dewasa mengonfigurasi akses dan menguji izin.
- Log, database SQLite untuk deduplikasi dan status.

## Instalasi Termux

Gunakan Android milik sendiri dengan izin pemilik perangkat. Minta orang tua/wali membantu mengelola akun developer, billing, dan token. Jangan pernah membagikan token di chat atau commit ke GitHub.

```bash
pkg update && pkg upgrade -y
pkg install python ffmpeg git -y
mkdir -p ~/veo-auto-publisher
cd ~/veo-auto-publisher
# Salin/clone berkas proyek ke folder ini
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

## Konfigurasi

- `GOOGLE_API_KEY`: API key Google AI Studio/Gemini API.
- `VEO_MODEL`: nama model Veo yang tersedia pada akun/API.
- `META_GRAPH_VERSION`: versi Graph API yang dipakai aplikasi Meta.
- `META_PAGE_ID`, `META_PAGE_ACCESS_TOKEN`: kredensial Page yang valid.
- `PUBLISH_MODE=review` adalah default aman. Jangan ubah ke `publish` sebelum admin Page memeriksa izin, privasi, dan proses uji.

## Jalankan

Buat satu draft uji:

```bash
python main.py once --topic hewan
```

Jalankan scheduler:

```bash
python main.py schedule
```

Periksa output di `output/review/`. Scheduler hanya berjalan saat proses Termux hidup. Android dapat menghentikan proses karena optimasi baterai, reboot, atau memori. Untuk jadwal yang dapat diandalkan, gunakan layanan terkelola dengan pengawasan orang dewasa; jangan menganggap ponsel sebagai server 24/7.

## Publikasi Facebook Page

Meta Reels Publishing API ditujukan untuk Page, bukan profil pribadi. Panduan endpoint dan izin dapat berubah. Lihat dokumentasi resmi Meta: https://developers.facebook.com/docs/graph-api/ dan koleksi dokumentasi Meta: https://www.postman.com/meta/facebook/ .

Modul `facebook_publisher.py` menyediakan kerangka dua fase `video_reels` (START, upload bytes, FINISH), tetapi publikasi dinonaktifkan kecuali `PUBLISH_MODE=publish`. Pastikan aplikasi Meta memiliki izin yang diperlukan, Page access token terkait Page, tugas Page yang sesuai, serta versi API yang masih berlaku. Lakukan pengujian pada Page uji terlebih dahulu.

## Fakta & tanggung jawab editorial

Jangan memakai konten `sample` sebagai fakta siap tayang tanpa memeriksa sumbernya. Isi `data/facts.json` dengan fakta yang sudah dicek dari sumber primer/ilmiah tepercaya. Sertakan sumber di caption atau metadata. Konten AI harus diberi label sesuai aturan platform dan kebijakan yang berlaku.

## Struktur

```text
veo-auto-publisher/
├── main.py
├── config.py
├── scheduler.py
├── veo_generator.py
├── video_postprocess.py
├── facebook_publisher.py
├── content.py
├── storage.py
├── requirements.txt
├── .env.example
├── .gitignore
├── data/facts.json
├── output/review/.gitkeep
└── logs/.gitkeep
```
