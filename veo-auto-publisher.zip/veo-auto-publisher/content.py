import json, random
from pathlib import Path

FACTS_PATH = Path("data/facts.json")

def choose_fact(topic: str | None = None, exclude: set[str] | None = None) -> dict:
    records = json.loads(FACTS_PATH.read_text(encoding="utf-8"))
    exclude = exclude or set()
    eligible = [r for r in records if (not topic or r["topic"] == topic) and r["id"] not in exclude]
    if not eligible:
        raise RuntimeError("Tidak ada fakta tersedia. Tambahkan fakta baru yang sudah diverifikasi ke data/facts.json")
    item = random.choice(eligible)
    for key in ("id", "title", "fact", "source_name", "source_url", "visual_prompt", "topic"):
        if not item.get(key):
            raise ValueError(f"Fakta tidak lengkap: {key}")
    return item

def build_caption(item: dict) -> str:
    tags = " ".join(f"#{x}" for x in ["FaktaUnik", "TahukahKamu", item["topic"].capitalize(), "Edukasi"])
    return (f"{item['title']}\n\n{item['fact']}\n\n"
            f"Sumber: {item['source_name']} — {item['source_url']}\n\n"
            f"{tags}\n\n"
            "Visual dibuat dengan AI; informasi bersumber dari referensi yang dicantumkan.")

def build_video_prompt(item: dict) -> str:
    return (f"Create a vertical 9:16 educational documentary video. Visual subject: {item['visual_prompt']} "
            "Natural movement, realistic details, no generated text, no logos, no fabricated scientific diagrams. "
            "The visuals illustrate the topic only; do not add factual claims or labels.")
