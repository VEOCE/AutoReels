from apscheduler.schedulers.blocking import BlockingScheduler
from zoneinfo import ZoneInfo
from main import create_draft
from config import settings

SLOTS = [(6, 0), (9, 0), (12, 0), (15, 0), (19, 0)]

def start_scheduler():
    scheduler = BlockingScheduler(timezone=ZoneInfo(settings.timezone))
    for hour, minute in SLOTS:
        scheduler.add_job(create_draft, "cron", hour=hour, minute=minute,
                          id=f"fact-{hour:02d}{minute:02d}", max_instances=1,
                          coalesce=True, misfire_grace_time=1800)
    print(f"Scheduler aktif ({settings.timezone}); 5 draft per hari.")
    scheduler.start()
