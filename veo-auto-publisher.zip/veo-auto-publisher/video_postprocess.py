from pathlib import Path
import subprocess

def make_15s_vertical(source: Path, destination: Path) -> Path:
    """Convert Veo clip to 15 seconds. Looping is a fallback; inspect for visible repetition."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-stream_loop", "1", "-i", str(source), "-t", "15",
           "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,format=yuv420p",
           "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-movflags", "+faststart", str(destination)]
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    return destination
