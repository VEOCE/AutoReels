import sqlite3
from pathlib import Path
from datetime import date

def init_db(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as con:
        con.execute("CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, created_at TEXT DEFAULT CURRENT_TIMESTAMP, topic TEXT, status TEXT, video_path TEXT, caption TEXT, source_url TEXT, fb_video_id TEXT)")

def already_used(path: Path, fact_id: str) -> bool:
    with sqlite3.connect(path) as con:
        row = con.execute("SELECT 1 FROM jobs WHERE id=? AND date(created_at)=date('now','localtime')", (fact_id,)).fetchone()
        return row is not None

def save_job(path: Path, item: dict, status: str, video: Path, caption: str):
    with sqlite3.connect(path) as con:
        con.execute("INSERT OR REPLACE INTO jobs(id,topic,status,video_path,caption,source_url) VALUES(?,?,?,?,?,?)",
                    (item["id"], item["topic"], status, str(video), caption, item["source_url"]))
